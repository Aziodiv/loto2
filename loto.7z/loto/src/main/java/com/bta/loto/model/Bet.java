package com.bta.loto.model;

import java.time.LocalDateTime;

public class Bet {

    private Integer number1;
    private Integer number2;
    private Integer number3;
    private Integer number4;
    private Integer number5;
    private Integer number6;
    private Integer number7;
    private Integer number8;
    private Integer number9;
    private Integer number10;
    private Integer number11;
    private Integer number12;
    private Integer number13;
    private Integer number14;
    private Integer number15;
    private Integer number16;
    private Integer number17;
    private Integer number18;
    private Integer number19;
    private Integer number20;
    private Integer number21;
    private Integer number22;
    private Integer number23;
    private Integer number24;

    private Long userAccountId;

    private LocalDateTime dateTime;

    public Bet(Integer number1, Integer number2, Integer number3,
               Integer number4, Integer number5, Integer number6,
               Integer number7, Integer number8, Integer number9,
               Integer number10, Integer number11, Integer number12,
               Integer number13, Integer number14, Integer number15,
               Integer number16, Integer number17, Integer number18,
               Integer number19, Integer number20, Integer number21,
               Integer number22, Integer number23, Integer number24,
               LocalDateTime dateTime)

    {
        this(number1,number2,number3,number4,number5,number6,number7,number8
                ,number9,number10,number11,number12,number13,number14,number15,
                number16,number17,number18,number19,number20,number21,number22,
                number23,number24,null,dateTime);

        this.number1 = number1;
        this.number2 = number2;
        this.number3 = number3;
        this.number4 = number4;
        this.number5 = number5;
        this.number6 = number6;
        this.number7 = number7;
        this.number8 = number8;
        this.number9 = number9;
        this.number10 = number10;
        this.number11 = number11;
        this.number12 = number12;
        this.number13 = number13;
        this.number14 = number14;
        this.number15 = number15;
        this.number16 = number16;
        this.number17 = number17;
        this.number18 = number18;
        this.number19 = number19;
        this.number20 = number20;
        this.number21 = number21;
        this.number22 = number22;
        this.number23 = number23;
        this.number24 = number24;
        this.dateTime = dateTime;
    }

    public Bet(Integer number1, Integer number2, Integer number3, Integer number4, Integer number5, Integer number6, Integer number7, Integer number8, Integer number9, Integer number10, Integer number11, Integer number12, Integer number13, Integer number14, Integer number15, Integer number16, Integer number17, Integer number18, Integer number19, Integer number20, Integer number21, Integer number22, Integer number23, Integer number24, Object o, LocalDateTime dateTime) {

        this.number1 = this.number1;
        this.number2 = this.number2;
        this.number3 = this.number3;
        this.number4 = this.number4;
        this.number5 = this.number5;
        this.number6 = this.number6;
        this.number7 = this.number7;
        this.number8 = this.number8;
        this.number9 = this.number9;
        this.number10 = this.number10;
        this.number11 = this.number11;
        this.number12 = this.number12;
        this.number13 = this.number13;
        this.number14 = this.number14;
        this.number15 = this.number15;
        this.number16 = this.number16;
        this.number17 = this.number17;
        this.number18 = this.number18;
        this.number19 = this.number19;
        this.number20 = this.number20;
        this.number21 = this.number21;
        this.number22 = this.number22;
        this.number23 = this.number23;
        this.number24 = this.number24;
        this.userAccountId = userAccountId;
        this.dateTime = this.dateTime;
    }

    public Integer getNumber1() {
        return number1;
    }

    public void setNumber1(Integer number1) {
        this.number1 = number1;
    }

    public Integer getNumber2() {
        return number2;
    }

    public void setNumber2(Integer number2) {
        this.number2 = number2;
    }

    public Integer getNumber3() {
        return number3;
    }

    public void setNumber3(Integer number3) {
        this.number3 = number3;
    }

    public Integer getNumber4() {
        return number4;
    }

    public void setNumber4(Integer number4) {
        this.number4 = number4;
    }

    public Integer getNumber5() {
        return number5;
    }

    public void setNumber5(Integer number5) {
        this.number5 = number5;
    }

    public Integer getNumber6() {
        return number6;
    }

    public void setNumber6(Integer number6) {
        this.number6 = number6;
    }

    public Integer getNumber7() {
        return number7;
    }

    public void setNumber7(Integer number7) {
        this.number7 = number7;
    }

    public Integer getNumber8() {
        return number8;
    }

    public void setNumber8(Integer number8) {
        this.number8 = number8;
    }

    public Integer getNumber9() {
        return number9;
    }

    public void setNumber9(Integer number9) {
        this.number9 = number9;
    }

    public Integer getNumber10() {
        return number10;
    }

    public void setNumber10(Integer number10) {
        this.number10 = number10;
    }

    public Integer getNumber11() {
        return number11;
    }

    public void setNumber11(Integer number11) {
        this.number11 = number11;
    }

    public Integer getNumber12() {
        return number12;
    }

    public void setNumber12(Integer number12) {
        this.number12 = number12;
    }

    public Integer getNumber13() {
        return number13;
    }

    public void setNumber13(Integer number13) {
        this.number13 = number13;
    }

    public Integer getNumber14() {
        return number14;
    }

    public void setNumber14(Integer number14) {
        this.number14 = number14;
    }

    public Integer getNumber15() {
        return number15;
    }

    public void setNumber15(Integer number15) {
        this.number15 = number15;
    }

    public Integer getNumber16() {
        return number16;
    }

    public void setNumber16(Integer number16) {
        this.number16 = number16;
    }

    public Integer getNumber17() {
        return number17;
    }

    public void setNumber17(Integer number17) {
        this.number17 = number17;
    }

    public Integer getNumber18() {
        return number18;
    }

    public void setNumber18(Integer number18) {
        this.number18 = number18;
    }

    public Integer getNumber19() {
        return number19;
    }

    public void setNumber19(Integer number19) {
        this.number19 = number19;
    }

    public Integer getNumber20() {
        return number20;
    }

    public void setNumber20(Integer number20) {
        this.number20 = number20;
    }

    public Integer getNumber21() {
        return number21;
    }

    public void setNumber21(Integer number21) {
        this.number21 = number21;
    }

    public Integer getNumber22() {
        return number22;
    }

    public void setNumber22(Integer number22) {
        this.number22 = number22;
    }

    public Integer getNumber23() {
        return number23;
    }

    public void setNumber23(Integer number23) {
        this.number23 = number23;
    }

    public Integer getNumber24() {
        return number24;
    }

    public void setNumber24(Integer number24) {
        this.number24 = number24;
    }

    public Long getUserAccountId() {
        return userAccountId;
    }

    public void setUserAccountId(Long userAccountId) {
        this.userAccountId = userAccountId;
    }

    public LocalDateTime getDateTime() {
        return dateTime;
    }

    public void setDateTime(LocalDateTime dateTime) {
        this.dateTime = dateTime;
    }
}
