package com.bta.loto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LotoApplicationTests {

	@Test
	void contextLoads() {
	}

}
